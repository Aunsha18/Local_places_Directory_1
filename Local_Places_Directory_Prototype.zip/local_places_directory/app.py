import streamlit as st
from pathlib import Path
from datetime import datetime
import pandas as pd
from places_directory.storage import load_places, save_places, export_csv
from places_directory.logic import search_places, summary, validate_place
from places_directory.reports import write_markdown_report, write_text_report

st.set_page_config(page_title="Local Places Directory", page_icon="📍", layout="wide")
ROOT = Path(__file__).parent
DATA = ROOT / "data" / "places.json"

st.markdown("""
<style>
.block-container {padding-top: 1.8rem; max-width: 1200px;}
.hero {padding: 1.35rem 1.6rem; border-radius: 16px; background: linear-gradient(115deg,#102a43,#1f6f78); color:white; margin-bottom:1rem;}
.hero h1 {color:white; margin:0; font-size:2rem;}
.hero p {color:#d9edf0; margin:.35rem 0 0;}
div[data-testid="stMetric"] {background:#f3f7fa; padding:14px; border-radius:12px; border:1px solid #e1eaf0;}
</style>
<div class="hero"><h1>📍 Local Places Directory</h1><p>Find, manage and understand useful places in your community.</p></div>
""", unsafe_allow_html=True)

if "places" not in st.session_state:
    st.session_state.places = load_places(DATA)

def persist():
    save_places(DATA, st.session_state.places)
    export_csv(ROOT / "data" / "places.csv", st.session_state.places)

places = st.session_state.places
stats = summary(places)
m1,m2,m3,m4 = st.columns(4)
m1.metric("Total places", stats["total"])
m2.metric("Open now/status", stats["open"])
m3.metric("Categories", stats["categories"])
m4.metric("Average rating", f'{stats["average_rating"]:.1f} / 5')

tab1, tab2, tab3, tab4 = st.tabs(["🔎 Explore places", "➕ Add a place", "📊 Insights & reports", "🛠 Manage records"])

with tab1:
    st.subheader("Find a useful place")
    c1,c2,c3 = st.columns([2,1,1])
    keyword = c1.text_input("Search by name, area or description", placeholder="e.g. library, Madhapur...")
    categories = ["All"] + sorted({p["category"] for p in places})
    category = c2.selectbox("Category", categories)
    statuses = ["All","Open","Closed","Maintenance"]
    status = c3.selectbox("Status", statuses)
    results = search_places(places, keyword=keyword, category=category, status=status)
    st.caption(f"{len(results)} matching place(s)")
    if results:
        df = pd.DataFrame(results)[["name","category","area","city","status","hours","rating","description"]]
        st.dataframe(df, use_container_width=True, hide_index=True)
    else:
        st.info("No matching places. Try another keyword or filter.")

with tab2:
    st.subheader("Add a new directory entry")
    with st.form("add_place", clear_on_submit=True):
        a,b = st.columns(2)
        name = a.text_input("Place name *")
        cat = b.selectbox("Category *", ["Library","Park","Transport","Healthcare","Education","Sports","Culture","Community","Other"])
        city = a.text_input("City *", value="Hyderabad")
        area = b.text_input("Area / neighbourhood *")
        status_new = a.selectbox("Status", ["Open","Closed","Maintenance"])
        hours = b.text_input("Opening hours", placeholder="09:00-18:00")
        rating = a.number_input("Rating (0 to 5)", min_value=0.0, max_value=5.0, value=4.0, step=0.1)
        desc = st.text_area("Description")
        submitted = st.form_submit_button("Save place", type="primary")
        if submitted:
            item = {"name":name,"category":cat,"city":city,"area":area,"status":status_new,"hours":hours,"rating":rating,"description":desc}
            errors = validate_place(item)
            if errors:
                for err in errors: st.error(err)
            else:
                item["id"] = max([int(p.get("id",0)) for p in places] or [0]) + 1
                places.append(item); persist()
                st.success(f'{name.strip()} added successfully.')
                st.rerun()

with tab3:
    st.subheader("Directory insights")
    c1,c2 = st.columns(2)
    with c1:
        st.markdown("**Places by category**")
        by_cat = pd.DataFrame([{"Category":k,"Places":v} for k,v in stats["by_category"].items()])
        if not by_cat.empty: st.bar_chart(by_cat.set_index("Category"))
    with c2:
        st.markdown("**Status distribution**")
        by_status = pd.DataFrame([{"Status":k,"Places":v} for k,v in stats["by_status"].items()])
        if not by_status.empty: st.bar_chart(by_status.set_index("Status"))
    st.markdown("**Quick observations**")
    st.write(f'- {stats["open"]} places are marked Open.')
    st.write(f'- {stats["categories"]} distinct categories are represented.')
    st.write(f'- Average user rating across records: {stats["average_rating"]:.2f}/5.')
    st.write(f'- {stats["needs_attention"]} records are not marked Open and may need review.')
    st.divider()
    st.markdown("**Export reports**")
    if st.button("Generate Markdown and text reports"):
        md_path = write_markdown_report(ROOT / "reports" / "directory_summary.md", places, stats)
        txt_path = write_text_report(ROOT / "reports" / "directory_audit.txt", places, stats)
        st.success("Reports generated in the reports/ folder.")
    for path in [ROOT/"reports"/"directory_summary.md", ROOT/"reports"/"directory_audit.txt", ROOT/"data"/"places.csv"]:
        if path.exists():
            st.download_button(f"Download {path.name}", path.read_bytes(), file_name=path.name)

with tab4:
    st.subheader("Update or remove a record")
    if not places:
        st.info("No records to manage.")
    else:
        labels = {f'{p["id"]} — {p["name"]}':p["id"] for p in places}
        selected_label = st.selectbox("Choose a place", list(labels.keys()))
        selected_id = labels[selected_label]
        item = next(p for p in places if p["id"] == selected_id)
        with st.form("edit_place"):
            x,y = st.columns(2)
            ename = x.text_input("Name", value=item["name"])
            ecat = y.text_input("Category", value=item["category"])
            ecity = x.text_input("City", value=item["city"])
            earea = y.text_input("Area", value=item["area"])
            estat = x.selectbox("Status", ["Open","Closed","Maintenance"], index=["Open","Closed","Maintenance"].index(item["status"]) if item["status"] in ["Open","Closed","Maintenance"] else 0)
            ehours = y.text_input("Hours", value=item.get("hours",""))
            erating = x.number_input("Rating", min_value=0.0, max_value=5.0, value=float(item.get("rating",0)), step=0.1)
            edesc = st.text_area("Description", value=item.get("description",""))
            save_edit = st.form_submit_button("Update selected place", type="primary")
            if save_edit:
                updated = {"name":ename,"category":ecat,"city":ecity,"area":earea,"status":estat,"hours":ehours,"rating":erating,"description":edesc}
                errors = validate_place(updated)
                if errors:
                    for err in errors: st.error(err)
                else:
                    item.update({k:(v.strip() if isinstance(v,str) else v) for k,v in updated.items()})
                    persist(); st.success("Record updated."); st.rerun()
        if st.button("Delete selected place", type="secondary"):
            st.session_state.places = [p for p in places if p["id"] != selected_id]
            persist(); st.success("Record deleted."); st.rerun()

st.caption("Local-first prototype • Data is stored in your project folder • Sample dataset is for demonstration")
