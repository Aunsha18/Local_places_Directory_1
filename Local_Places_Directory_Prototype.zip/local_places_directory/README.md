# Local Places Directory

A beginner-friendly Python application prototype for Hackathon Project #57 — Local Places Directory.

## Features
- Streamlit web interface with dashboard and four working sections
- Add, edit, delete, keyword search and category/status filters
- Defensive validation for required fields and ratings (0–5)
- JSON persistence and automatic CSV export
- Executive summary, category/status charts and Markdown/text reports
- 35 seeded sample records
- Unit tests for search, validation and summary calculations
- Corrupt/missing JSON recovery

## Requirements
- Python 3.10 or newer
- pip and an internet connection for the first-time dependency installation

## Run on Windows
1. Extract the ZIP file.
2. Open the extracted `local_places_directory` folder.
3. Open Command Prompt in that folder.
4. Run:

```bash
python -m venv .venv
.venv\\Scripts\\activate
pip install -r requirements.txt
streamlit run app.py
```

## Run on macOS / Linux

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
streamlit run app.py
```

The app opens in your browser (usually `http://localhost:8501`).

## Project structure

```text
local_places_directory/
├── app.py
├── data/
│   ├── places.json
│   └── places.csv
├── places_directory/
│   ├── __init__.py
│   ├── logic.py
│   ├── reports.py
│   └── storage.py
├── reports/
├── tests/
│   └── test_logic.py
├── requirements.txt
├── run_windows.bat
├── run_unix.sh
└── README.md
```

## Run tests
From the project root:

```bash
python -m unittest discover -s tests -v
```

## Data notes
The bundled Hyderabad place records are fictional demonstration/sample records, not verified live listings. Edit or replace them with your curated directory before public use. The app stores data locally in `data/places.json` and refreshes `data/places.csv` when records are changed.

## Demo flow
1. Open Explore places and search for `library`.
2. Filter by a category and status.
3. Add a new place and leave a required field blank to show validation.
4. Open Manage records to update or delete a sample.
5. Open Insights & reports to view charts and export reports.
6. Stop and restart the app to demonstrate JSON persistence.
