import unittest
from places_directory.logic import validate_place, search_places, summary

SAMPLE = [{"id":1,"name":"Central Library","category":"Library","city":"Hyderabad","area":"Abids","status":"Open","rating":4.5,"description":"Study space"}]

class LogicTests(unittest.TestCase):
    def test_search_keyword(self):
        self.assertEqual(len(search_places(SAMPLE, keyword="library")), 1)
    def test_search_category(self):
        self.assertEqual(len(search_places(SAMPLE, category="Library")), 1)
    def test_validation(self):
        self.assertEqual(validate_place(SAMPLE[0]), [])
    def test_rating_range(self):
        item = dict(SAMPLE[0], rating=7)
        self.assertTrue(any("Rating" in e for e in validate_place(item)))
    def test_summary(self):
        result = summary(SAMPLE)
        self.assertEqual(result["total"], 1)
        self.assertEqual(result["open"], 1)

if __name__ == "__main__":
    unittest.main()
