import csv, json
from pathlib import Path

def load_places(path):
    path = Path(path)
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(data, list):
            raise ValueError("Directory JSON must contain a list of records.")
        return data
    except FileNotFoundError:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text("[]", encoding="utf-8")
        return []
    except (json.JSONDecodeError, ValueError):
        backup = path.with_suffix(path.suffix + ".corrupt")
        path.replace(backup)
        path.write_text("[]", encoding="utf-8")
        return []

def save_places(path, places):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_suffix(".tmp")
    temp.write_text(json.dumps(places, indent=2, ensure_ascii=False), encoding="utf-8")
    temp.replace(path)

def export_csv(path, places):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fields = ["id","name","category","city","area","status","hours","rating","description"]
    with path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(places)
