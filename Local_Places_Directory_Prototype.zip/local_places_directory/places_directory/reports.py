from datetime import datetime
from pathlib import Path

def write_markdown_report(path, places, stats):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    lines = ["# Local Places Directory — Summary", "", f"Generated: {datetime.now():%Y-%m-%d %H:%M}", "",
             "## Executive summary", f"- Total places: {stats['total']}", f"- Open places: {stats['open']}",
             f"- Categories: {stats['categories']}", f"- Average rating: {stats['average_rating']:.2f}/5", "",
             "## Places by category"]
    lines += [f"- {k}: {v}" for k,v in stats["by_category"].items()]
    lines += ["", "## Directory records", "| ID | Name | Category | Area | Status |", "|---:|---|---|---|---|"]
    lines += [f"| {p.get('id','')} | {p.get('name','')} | {p.get('category','')} | {p.get('area','')} | {p.get('status','')} |" for p in places]
    path.write_text("\\n".join(lines), encoding="utf-8")
    return path

def write_text_report(path, places, stats):
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    lines = ["LOCAL PLACES DIRECTORY — AUDIT LOG", f"Generated: {datetime.now():%Y-%m-%d %H:%M}", "",
             f"Total records: {stats['total']}", f"Open records: {stats['open']}",
             f"Average rating: {stats['average_rating']:.2f}/5", "", "RECORDS"]
    lines += [f"#{p.get('id')} | {p.get('name')} | {p.get('category')} | {p.get('area')} | {p.get('status')}" for p in places]
    path.write_text("\\n".join(lines), encoding="utf-8")
    return path
