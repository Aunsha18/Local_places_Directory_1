from collections import Counter

def validate_place(place):
    errors = []
    for field in ("name","category","city","area"):
        if not str(place.get(field, "")).strip():
            errors.append(f"{field.title()} is required.")
        elif len(str(place[field]).strip()) > 100:
            errors.append(f"{field.title()} must be 100 characters or fewer.")
    try:
        rating = float(place.get("rating", 0))
        if not 0 <= rating <= 5:
            errors.append("Rating must be between 0 and 5.")
    except (TypeError, ValueError):
        errors.append("Rating must be a number between 0 and 5.")
    if place.get("status") not in ("Open","Closed","Maintenance"):
        errors.append("Status must be Open, Closed or Maintenance.")
    return errors

def search_places(places, keyword="", category="All", status="All"):
    q = keyword.casefold().strip()
    results = []
    for p in places:
        haystack = " ".join(str(p.get(k,"")) for k in ("name","category","city","area","description")).casefold()
        if q and q not in haystack: continue
        if category != "All" and p.get("category") != category: continue
        if status != "All" and p.get("status") != status: continue
        results.append(p)
    return results

def summary(places):
    by_category = dict(sorted(Counter(p.get("category","Uncategorised") for p in places).items()))
    by_status = dict(sorted(Counter(p.get("status","Unknown") for p in places).items()))
    ratings = []
    for p in places:
        try: ratings.append(float(p.get("rating",0)))
        except (TypeError,ValueError): pass
    return {
        "total":len(places),
        "open":sum(1 for p in places if p.get("status")=="Open"),
        "categories":len(by_category),
        "average_rating":sum(ratings)/len(ratings) if ratings else 0.0,
        "needs_attention":sum(1 for p in places if p.get("status")!="Open"),
        "by_category":by_category,
        "by_status":by_status,
    }
